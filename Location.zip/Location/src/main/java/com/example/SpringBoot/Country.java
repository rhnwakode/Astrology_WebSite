package com.example.SpringBoot;

public class Country {
	
	private String country;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Country(String country) {
		super();
		this.country = country;
	}
	

}
